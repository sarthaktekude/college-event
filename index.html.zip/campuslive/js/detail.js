document.addEventListener("DOMContentLoaded", () => {
  renderChrome("events");
  Store.seedIfEmpty();

  const id = qs("id");
  const event = id ? Store.getEvent(id) : null;
  const host = document.getElementById("detail-root");

  if (!event) {
    host.innerHTML = `
      <div class="empty-state">
        <h3>We couldn't find that event</h3>
        <p>It may have been removed by its organizer, or the link is incorrect.</p>
        <a class="btn btn--primary" href="events.html">Browse all events</a>
      </div>`;
    document.title = "Event not found — CampusLive";
    return;
  }

  document.title = `${event.title} — CampusLive`;
  render(event);
});

function render(e) {
  const host = document.getElementById("detail-root");
  const days = Store.daysUntil(e.date);
  const isFree = !Number(e.entryFee);

  let statusLine = `${days} day${days === 1 ? "" : "s"} until the event`;
  if (days < 0) statusLine = "This event has already taken place";
  if (days === 0) statusLine = "Happening today";

  const deadlineDays = e.deadline ? Store.daysUntil(e.deadline) : null;

  host.innerHTML = `
    <div class="detail-hero">
      <div class="detail-top">
        <span class="event-card-cat">${escapeHTML(e.category)}</span>
        <h1 class="detail-title">${escapeHTML(e.title)}</h1>
        <p class="detail-college">Hosted by <b>${escapeHTML(e.college)}</b>${e.city ? `, ${escapeHTML(e.city)}` : ""}</p>
      </div>
      <div class="detail-grid">
        <div class="detail-item"><div class="label">Date</div><div class="value">${Store.formatDate(e.date)}</div></div>
        <div class="detail-item"><div class="label">Time</div><div class="value">${escapeHTML(e.time || "TBA")}</div></div>
        <div class="detail-item"><div class="label">Mode</div><div class="value">${escapeHTML(e.mode || "Offline")}</div></div>
        <div class="detail-item"><div class="label">Team size</div><div class="value">${escapeHTML(e.teamSize || "Individual")}</div></div>
        ${e.deadline ? `<div class="detail-item"><div class="label">Register by</div><div class="value">${Store.formatDate(e.deadline)}</div></div>` : ""}
        <div class="detail-item"><div class="label">Status</div><div class="value">${escapeHTML(statusLine)}</div></div>
      </div>
      <div class="ticket-tear"></div>
      <div class="detail-bottom">
        <div class="fee-block">
          <div class="label">Entry fee</div>
          <div class="amount ${isFree ? "is-free" : ""}">${Store.formatFee(e.entryFee)}</div>
        </div>
        ${
          e.registrationLink
            ? `<a class="btn btn--accent" href="${escapeHTML(e.registrationLink)}" target="_blank" rel="noopener">Register now →</a>`
            : `<span class="callout callout--info" style="margin:0;">No online link provided — use the contact details below to register.</span>`
        }
      </div>
    </div>

    <div class="detail-body">
      <h2>About this event</h2>
      <p>${escapeHTML(e.description || "No description provided yet.")}</p>
      ${e.venue ? `<h2 style="margin-top:26px;">Venue</h2><p>📍 ${escapeHTML(e.venue)}</p>` : ""}
    </div>

    <div class="contact-card">
      <h3>Organizer contact</h3>
      <div class="contact-row"><b>Name</b><span>${escapeHTML(e.organizerName || "Not provided")}</span></div>
      ${e.contactEmail ? `<div class="contact-row"><b>Email</b><span>${escapeHTML(e.contactEmail)}</span></div>` : ""}
      ${e.contactPhone ? `<div class="contact-row"><b>Phone</b><span>${escapeHTML(e.contactPhone)}</span></div>` : ""}
    </div>

    <div style="max-width:760px;margin:24px auto 0;">
      <a class="btn btn--ghost" href="events.html">← Back to all events</a>
    </div>
  `;
}
