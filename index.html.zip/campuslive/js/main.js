/**
 * CampusLive — shared UI helpers.
 * Loaded on every page, after store.js.
 */

/** Escape untrusted text before inserting into innerHTML. Prevents markup/script injection from event data. */
function escapeHTML(str) {
  if (str === null || str === undefined) return "";
  return String(str)
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}

function qs(name) {
  return new URLSearchParams(window.location.search).get(name);
}

function showToast(message, tone = "default") {
  let host = document.getElementById("toast-host");
  if (!host) {
    host = document.createElement("div");
    host.id = "toast-host";
    host.setAttribute("aria-live", "polite");
    document.body.appendChild(host);
  }
  const toast = document.createElement("div");
  toast.className = "toast toast--" + tone;
  toast.textContent = message;
  host.appendChild(toast);
  requestAnimationFrame(() => toast.classList.add("toast--in"));
  setTimeout(() => {
    toast.classList.remove("toast--in");
    setTimeout(() => toast.remove(), 250);
  }, 3200);
}

function renderChrome(activePage) {
  const header = document.getElementById("site-header");
  const footer = document.getElementById("site-footer");

  if (header) {
    header.innerHTML = `
      <div class="nav-wrap">
        <a class="brand" href="index.html" aria-label="CampusLive home">
          <span class="brand-mark" aria-hidden="true">
            <svg viewBox="0 0 32 32" width="26" height="26">
              <circle cx="16" cy="16" r="15" fill="none" stroke="currentColor" stroke-width="2"/>
              <path d="M16 8 L23 12 L16 16 L9 12 Z" fill="currentColor"/>
              <path d="M9 15 V20 C9 22 12 23.5 16 23.5 C20 23.5 23 22 23 20 V15" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>
            </svg>
          </span>
          <span class="brand-name">Campus<em>Live</em></span>
        </a>
        <nav class="main-nav" aria-label="Primary">
          <a href="events.html" class="${activePage === "events" ? "is-active" : ""}">Browse events</a>
          <a href="post-event.html" class="${activePage === "post" ? "is-active" : ""}">Post an event</a>
          <a href="my-events.html" class="${activePage === "my" ? "is-active" : ""}">Manage my event</a>
          <a href="about.html" class="${activePage === "about" ? "is-active" : ""}">About</a>
        </nav>
        <a class="btn btn--accent nav-cta" href="post-event.html">+ Post event</a>
        <button class="nav-toggle" id="nav-toggle" aria-expanded="false" aria-controls="mobile-nav" aria-label="Open menu">
          <span></span><span></span><span></span>
        </button>
      </div>
      <nav id="mobile-nav" class="mobile-nav" aria-label="Mobile">
        <a href="events.html">Browse events</a>
        <a href="post-event.html">Post an event</a>
        <a href="my-events.html">Manage my event</a>
        <a href="about.html">About</a>
      </nav>
    `;
    const toggle = document.getElementById("nav-toggle");
    const mobileNav = document.getElementById("mobile-nav");
    toggle?.addEventListener("click", () => {
      const open = mobileNav.classList.toggle("is-open");
      toggle.setAttribute("aria-expanded", String(open));
    });
  }

  if (footer) {
    footer.innerHTML = `
      <div class="footer-wrap">
        <div class="footer-brand">
          <span class="brand-name">Campus<em>Live</em></span>
          <p>One board for every college fest, hackathon, and seminar — built for students who don't want to miss out.</p>
        </div>
        <div class="footer-cols">
          <div>
            <h4>Explore</h4>
            <a href="events.html">Browse events</a>
            <a href="events.html?category=Hackathon">Hackathons</a>
            <a href="events.html?category=Cultural%20Fest">Cultural fests</a>
          </div>
          <div>
            <h4>Organize</h4>
            <a href="post-event.html">Post an event</a>
            <a href="my-events.html">Edit or remove an event</a>
          </div>
          <div>
            <h4>Project</h4>
            <a href="about.html">About CampusLive</a>
            <a href="https://github.com/" target="_blank" rel="noopener">View on GitHub</a>
          </div>
        </div>
      </div>
      <div class="footer-bottom">
        <span>© ${new Date().getFullYear()} CampusLive. Built as an open-source campus events board.</span>
      </div>
    `;
  }
}

document.addEventListener("DOMContentLoaded", () => {
  try {
    Store.seedIfEmpty();
  } catch (err) {
    console.error("CampusLive: seeding failed", err);
  }
});
