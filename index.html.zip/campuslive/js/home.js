document.addEventListener("DOMContentLoaded", () => {
  renderChrome("home");
  Store.seedIfEmpty();
  renderStats();
  renderFeatured();
});

function renderStats() {
  const events = Store.getEvents();
  const upcoming = events.filter((e) => Store.daysUntil(e.date) >= 0);
  const colleges = new Set(events.map((e) => e.college)).size;

  const statEvents = document.getElementById("stat-events");
  const statColleges = document.getElementById("stat-colleges");
  const statFree = document.getElementById("stat-free");

  if (statEvents) statEvents.textContent = upcoming.length;
  if (statColleges) statColleges.textContent = colleges;
  if (statFree) statFree.textContent = events.filter((e) => !Number(e.entryFee)).length;
}

function renderFeatured() {
  const host = document.getElementById("featured-grid");
  if (!host) return;

  const events = Store.getEvents().filter((e) => Store.daysUntil(e.date) >= 0);
  const featured = events.slice(0, 6);

  if (featured.length === 0) {
    host.innerHTML = `
      <div class="empty-state" style="grid-column: 1 / -1;">
        <h3>No upcoming events yet</h3>
        <p>Be the first to put your college's event on the board.</p>
        <a class="btn btn--primary" href="post-event.html">Post the first event</a>
      </div>`;
    return;
  }

  host.innerHTML = featured.map(eventCardHTML).join("");
}

function eventCardHTML(e) {
  const days = Store.daysUntil(e.date);
  let badgeClass = "";
  let badgeText = `${days} day${days === 1 ? "" : "s"} left`;
  if (days < 0) { badgeClass = "is-past"; badgeText = "Event passed"; }
  else if (days <= 3) { badgeClass = "is-urgent"; badgeText = days === 0 ? "Happening today" : `${days} day${days === 1 ? "" : "s"} left`; }

  const fee = Store.formatFee(e.entryFee);
  const isFree = !Number(e.entryFee);

  return `
    <a class="event-card" href="event-detail.html?id=${encodeURIComponent(e.id)}">
      <div class="event-card-top">
        <span class="event-card-cat">${escapeHTML(e.category)}</span>
        <h3>${escapeHTML(e.title)}</h3>
        <p class="college">at <b>${escapeHTML(e.college)}</b></p>
        <div class="event-card-meta">
          <span>📅 ${Store.formatDate(e.date)} · ${escapeHTML(e.time || "")}</span>
          <span>📍 ${escapeHTML(e.venue || e.mode || "")}</span>
        </div>
      </div>
      <div class="event-card-stub">
        <span class="stub-fee ${isFree ? "is-free" : ""}">${fee}</span>
        <span class="badge-days ${badgeClass}">${badgeText}</span>
      </div>
    </a>`;
}
