document.addEventListener("DOMContentLoaded", () => {
  renderChrome("my");
  Store.seedIfEmpty();

  const searchInput = document.getElementById("my-search");
  searchInput?.addEventListener("input", renderList);

  const idFromUrl = qs("id");
  if (idFromUrl) {
    const event = Store.getEvent(idFromUrl);
    if (event && searchInput) searchInput.value = event.title;
  }

  renderList();
});

function renderList() {
  const host = document.getElementById("my-events-list");
  if (!host) return;
  const term = (document.getElementById("my-search")?.value || "").trim().toLowerCase();
  const events = Store.getEvents();

  const list = term
    ? events.filter(
        (e) =>
          e.title.toLowerCase().includes(term) || e.college.toLowerCase().includes(term)
      )
    : events;

  if (list.length === 0) {
    host.innerHTML = `
      <div class="empty-state">
        <h3>No matching events</h3>
        <p>Search by the event title or college name to find the event you posted.</p>
      </div>`;
    return;
  }

  host.innerHTML = list.map((e) => cardHTML(e)).join("");

  host.querySelectorAll("[data-unlock]").forEach((btn) => {
    btn.addEventListener("click", () => unlock(btn.dataset.unlock));
  });
}

function cardHTML(e) {
  return `
    <div class="manage-card" id="card-${e.id}">
      <div>
        <h3>${escapeHTML(e.title)}</h3>
        <p class="college">${escapeHTML(e.college)} · ${Store.formatDate(e.date)}</p>
      </div>
      <div class="manage-actions" id="actions-${e.id}">
        <input type="password" class="field-inline" placeholder="Passcode" id="pass-${e.id}"
          style="padding:9px 12px;border:1px solid var(--line-strong);border-radius:6px;width:130px;" />
        <button type="button" class="btn btn--ghost btn--sm" data-unlock="${e.id}">Unlock</button>
      </div>
    </div>`;
}

function unlock(id) {
  const passInput = document.getElementById(`pass-${id}`);
  const key = passInput?.value || "";
  const ok = Store.verifyKey(id, key);

  if (!ok) {
    showToast("Incorrect passcode for that event.", "danger");
    return;
  }

  const actions = document.getElementById(`actions-${id}`);
  actions.innerHTML = `
    <a class="btn btn--primary btn--sm" href="post-event.html?edit=${encodeURIComponent(id)}&key=${encodeURIComponent(key)}">Edit</a>
    <button type="button" class="btn btn--danger btn--sm" data-delete="${id}" data-key="${escapeHTML(key)}">Delete</button>
  `;
  actions.querySelector("[data-delete]").addEventListener("click", (e) => {
    const btn = e.currentTarget;
    if (!confirm("Delete this event? This can't be undone.")) return;
    const removed = Store.deleteEvent(btn.dataset.delete, btn.dataset.key);
    if (removed) {
      showToast("Event deleted.", "success");
      document.getElementById(`card-${id}`)?.remove();
    } else {
      showToast("Couldn't delete that event.", "danger");
    }
  });
}
