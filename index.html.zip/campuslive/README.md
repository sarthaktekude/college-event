# CampusLive

**One board for every college event.** Event managers post a hackathon, fest, workshop, or seminar once; students at any college can find it, filter it, and register.

> Built as a dependency-free static site — plain HTML, CSS, and JavaScript. No build step, no framework, no server required.

## ✨ Features

- **Post an event** — a structured form for title, college, category, date, venue, entry fee, team size, registration link, and organizer contact.
- **Browse & filter** — full-text search plus filters for category, college, and mode (Offline / Online / Hybrid), with sorting by date, fee, or recency.
- **Event detail pages** — a shareable, linkable page per event with a clear "days left" indicator and a direct registration link.
- **Manage my event** — organizers unlock edit/delete on their own event with the passcode they set when posting (no account system).
- **Resilient by design** — every storage read/write is wrapped in error handling, all user-entered text is HTML-escaped before rendering, and every page ships an empty state so nothing renders a blank or broken screen.
- **Accessible & responsive** — semantic landmarks, visible keyboard focus states, `prefers-reduced-motion` support, and a layout that works from a phone up to a wide desktop.

## 🧱 Tech stack

| Layer      | Choice                                   |
|------------|-------------------------------------------|
| Markup     | Semantic HTML5, one file per page          |
| Styling    | Hand-written CSS with a token-based design system (`css/style.css`) |
| Behaviour  | Vanilla JavaScript (ES6+), no framework    |
| Data       | Browser `localStorage`, isolated behind `js/store.js` |
| Fonts      | Space Grotesk (display), Inter (body), IBM Plex Mono (data) via Google Fonts |

No `npm install`, no bundler, no build step — clone it and open `index.html`, or serve the folder with any static file server.

## 📁 Project structure

```
campuslive/
├── index.html            Landing page — hero, live stats, featured events
├── events.html            Browse / search / filter all events
├── event-detail.html      Single event detail (reads ?id=)
├── post-event.html        Create or edit an event (reads ?edit=&key= for edits)
├── event-posted.html      Confirmation screen after publishing
├── my-events.html         Find + unlock an event with its passcode
├── about.html              Project background and roadmap
├── css/
│   └── style.css          Design tokens + every component style
├── js/
│   ├── store.js           Data layer: CRUD over localStorage, seed data, formatting helpers
│   ├── main.js             Shared header/footer render, toast notifications, escaping helpers
│   ├── home.js              Landing page logic
│   ├── events.js            Browse/filter page logic
│   ├── detail.js            Event detail page logic
│   ├── post.js               Post/edit form logic + validation
│   └── my-events.js          Manage-my-event page logic
└── README.md
```

## 🚀 Running locally

Any static file server works:

```bash
# Python
python3 -m http.server 8080

# Node
npx serve .
```

Then open `http://localhost:8080`.

## 🌐 Deploying to GitHub Pages

1. Push this folder to a GitHub repository.
2. In the repo, go to **Settings → Pages**.
3. Under **Build and deployment**, choose **Deploy from a branch**, select your default branch and the root (`/`) folder.
4. Save — GitHub will publish the site at `https://<username>.github.io/<repo>/`.

No further configuration is needed since the site has no build step.

## ⚠️ Current data model — read before using in production

Event data is stored in the visitor's **browser localStorage**, not a shared database. That keeps this version:

- free to host as a static site,
- fast, with zero backend to run or pay for,
- and simple to read end-to-end for learning or portfolio purposes.

It also means an event posted on one device won't automatically appear for a visitor on a different device or browser. For a real, shared campus-wide board, replace the internals of `js/store.js` with calls to a backend of your choice — the rest of the app already talks to `Store` through a small, stable API (`getEvents`, `addEvent`, `updateEvent`, `deleteEvent`, `verifyKey`, …), so no other file needs to change. Good options:

- **Firebase Firestore** — fastest to wire up, generous free tier, no server to run.
- **Supabase (Postgres)** — same idea with SQL underneath, plus built-in auth if you want real organizer accounts.
- **A small Express/Node API + Postgres/MongoDB** — full control, more setup.

Swapping in a backend is also the place to add real authentication for event managers instead of the current passcode-per-event model, which is intentionally lightweight and **not** a substitute for real auth.

## 🗺️ Roadmap ideas

- Backend integration for a shared, multi-device board (see above).
- Image upload for event posters (currently text-only by design, to keep the static-hosting model simple).
- Email verification for organizers before an event goes live.
- Per-college pages and RSS/calendar (.ics) export for upcoming events.

## 📄 License

MIT — see [LICENSE](LICENSE).
