let ALL_EVENTS = [];
let ACTIVE_CATEGORY = "All";

document.addEventListener("DOMContentLoaded", () => {
  renderChrome("events");
  Store.seedIfEmpty();
  ALL_EVENTS = Store.getEvents();

  populateCollegeOptions();
  buildCategoryChips();

  const categoryFromUrl = qs("category");
  if (categoryFromUrl) ACTIVE_CATEGORY = categoryFromUrl;
  const collegeFromUrl = qs("college");
  if (collegeFromUrl) document.getElementById("filter-college").value = collegeFromUrl;
  const searchFromUrl = qs("q");
  if (searchFromUrl) document.getElementById("filter-search").value = searchFromUrl;

  syncChipState();
  applyFilters();

  ["filter-search", "filter-college", "filter-mode", "filter-sort"].forEach((id) => {
    const el = document.getElementById(id);
    el?.addEventListener("input", applyFilters);
    el?.addEventListener("change", applyFilters);
  });

  document.getElementById("clear-filters")?.addEventListener("click", () => {
    document.getElementById("filter-search").value = "";
    document.getElementById("filter-college").value = "";
    document.getElementById("filter-mode").value = "";
    document.getElementById("filter-sort").value = "date-asc";
    ACTIVE_CATEGORY = "All";
    syncChipState();
    applyFilters();
  });
});

function populateCollegeOptions() {
  const select = document.getElementById("filter-college");
  if (!select) return;
  const colleges = Store.getColleges();
  colleges.forEach((c) => {
    const opt = document.createElement("option");
    opt.value = c;
    opt.textContent = c;
    select.appendChild(opt);
  });
}

function buildCategoryChips() {
  const host = document.getElementById("category-chips");
  if (!host) return;
  const categories = ["All", ...Store.getCategories()];
  host.innerHTML = categories
    .map((c) => `<button type="button" class="chip" data-cat="${escapeHTML(c)}">${escapeHTML(c)}</button>`)
    .join("");
  host.querySelectorAll(".chip").forEach((chip) => {
    chip.addEventListener("click", () => {
      ACTIVE_CATEGORY = chip.dataset.cat;
      syncChipState();
      applyFilters();
    });
  });
}

function syncChipState() {
  document.querySelectorAll("#category-chips .chip").forEach((chip) => {
    chip.classList.toggle("is-active", chip.dataset.cat === ACTIVE_CATEGORY);
  });
}

function applyFilters() {
  const search = (document.getElementById("filter-search")?.value || "").trim().toLowerCase();
  const college = document.getElementById("filter-college")?.value || "";
  const mode = document.getElementById("filter-mode")?.value || "";
  const sort = document.getElementById("filter-sort")?.value || "date-asc";

  let list = ALL_EVENTS.filter((e) => {
    const matchesSearch =
      !search ||
      e.title.toLowerCase().includes(search) ||
      e.college.toLowerCase().includes(search) ||
      (e.description || "").toLowerCase().includes(search);
    const matchesCategory = ACTIVE_CATEGORY === "All" || e.category === ACTIVE_CATEGORY;
    const matchesCollege = !college || e.college === college;
    const matchesMode = !mode || e.mode === mode;
    return matchesSearch && matchesCategory && matchesCollege && matchesMode;
  });

  if (sort === "date-asc") list.sort((a, b) => new Date(a.date) - new Date(b.date));
  if (sort === "date-desc") list.sort((a, b) => new Date(b.date) - new Date(a.date));
  if (sort === "fee-asc") list.sort((a, b) => Number(a.entryFee || 0) - Number(b.entryFee || 0));
  if (sort === "newest") list.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));

  renderResults(list);
}

function renderResults(list) {
  const grid = document.getElementById("results-grid");
  const count = document.getElementById("results-count");
  if (!grid) return;

  count.textContent = `${list.length} event${list.length === 1 ? "" : "s"} found`;

  if (list.length === 0) {
    grid.innerHTML = `
      <div class="empty-state" style="grid-column: 1 / -1;">
        <h3>No events match those filters</h3>
        <p>Try a different category, college, or clear your filters to see everything on the board.</p>
        <button class="btn btn--ghost" onclick="document.getElementById('clear-filters').click()">Clear filters</button>
      </div>`;
    return;
  }

  grid.innerHTML = list.map(cardHTML).join("");
}

function cardHTML(e) {
  const days = Store.daysUntil(e.date);
  let badgeClass = "";
  let badgeText = `${days} day${days === 1 ? "" : "s"} left`;
  if (days < 0) { badgeClass = "is-past"; badgeText = "Event passed"; }
  else if (days <= 3) { badgeClass = "is-urgent"; badgeText = days === 0 ? "Happening today" : badgeText; }

  const fee = Store.formatFee(e.entryFee);
  const isFree = !Number(e.entryFee);

  return `
    <a class="event-card" href="event-detail.html?id=${encodeURIComponent(e.id)}">
      <div class="event-card-top">
        <span class="event-card-cat">${escapeHTML(e.category)}</span>
        <h3>${escapeHTML(e.title)}</h3>
        <p class="college">at <b>${escapeHTML(e.college)}</b></p>
        <div class="event-card-meta">
          <span>📅 ${Store.formatDate(e.date)} · ${escapeHTML(e.time || "")}</span>
          <span>📍 ${escapeHTML(e.venue || e.mode || "")}</span>
        </div>
      </div>
      <div class="event-card-stub">
        <span class="stub-fee ${isFree ? "is-free" : ""}">${fee}</span>
        <span class="badge-days ${badgeClass}">${badgeText}</span>
      </div>
    </a>`;
}
