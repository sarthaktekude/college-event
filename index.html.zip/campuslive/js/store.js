/**
 * CampusLive — data layer
 * ---------------------------------------------------------
 * All event data lives in the browser's localStorage under the
 * key "campuslive.events.v1". Every read/write is wrapped in
 * try/catch so a corrupted or disabled storage layer degrades
 * gracefully instead of crashing the page.
 *
 * NOTE FOR DEVELOPERS:
 * This is a client-only data layer, intentional for a static,
 * no-backend deployment (e.g. GitHub Pages). Data is per-browser,
 * not shared across visitors. To make events visible to every
 * student/college in production, swap this module for calls to
 * a real backend (Firebase Firestore, Supabase, or a small
 * Express + Postgres API) while keeping the same function
 * signatures below — every page only talks to `Store`.
 */

const Store = (() => {
  const KEY = "campuslive.events.v1";
  const SEED_FLAG = "campuslive.seeded.v1";

  /** Generate a short, collision-resistant id without external libs. */
  function uid() {
    return (
      Date.now().toString(36) +
      "-" +
      Math.random().toString(36).slice(2, 9)
    );
  }

  /** Safe JSON read from localStorage. Never throws. */
  function readAll() {
    try {
      const raw = window.localStorage.getItem(KEY);
      if (!raw) return [];
      const parsed = JSON.parse(raw);
      return Array.isArray(parsed) ? parsed : [];
    } catch (err) {
      console.error("CampusLive: failed to read events", err);
      return [];
    }
  }

  /** Safe JSON write to localStorage. Returns true/false. */
  function writeAll(events) {
    try {
      window.localStorage.setItem(KEY, JSON.stringify(events));
      return true;
    } catch (err) {
      console.error("CampusLive: failed to save events", err);
      return false;
    }
  }

  function getEvents() {
    return readAll().sort((a, b) => new Date(a.date) - new Date(b.date));
  }

  function getEvent(id) {
    return readAll().find((e) => e.id === id) || null;
  }

  function addEvent(data) {
    const events = readAll();
    const event = {
      id: uid(),
      createdAt: new Date().toISOString(),
      ...data,
    };
    events.push(event);
    writeAll(events);
    return event;
  }

  function updateEvent(id, updates) {
    const events = readAll();
    const idx = events.findIndex((e) => e.id === id);
    if (idx === -1) return false;
    events[idx] = { ...events[idx], ...updates };
    return writeAll(events);
  }

  function deleteEvent(id, editKey) {
    const events = readAll();
    const idx = events.findIndex((e) => e.id === id);
    if (idx === -1) return false;
    if (events[idx].editKey && events[idx].editKey !== editKey) return false;
    events.splice(idx, 1);
    return writeAll(events);
  }

  function verifyKey(id, editKey) {
    const event = getEvent(id);
    if (!event) return false;
    return !event.editKey || event.editKey === editKey;
  }

  function getColleges() {
    const fromEvents = readAll().map((e) => e.college).filter(Boolean);
    return Array.from(new Set([...SEED_COLLEGES, ...fromEvents])).sort();
  }

  function getCategories() {
    return [
      "Hackathon",
      "Cultural Fest",
      "Tech Symposium",
      "Workshop",
      "Sports Meet",
      "Seminar / Guest Talk",
      "Competition",
      "Other",
    ];
  }

  // A representative list of colleges so the "college" field has
  // useful autocomplete suggestions even before any events exist.
  const SEED_COLLEGES = [
    "University of Mumbai",
    "K.J. Somaiya College of Engineering",
    "VJTI Mumbai",
    "St. Xavier's College, Mumbai",
    "Jai Hind College",
    "R.A. Podar College of Commerce & Economics",
    "Sydenham College of Commerce & Economics",
    "Sardar Patel Institute of Technology",
    "D.J. Sanghvi College of Engineering",
    "Ramnarain Ruia Autonomous College",
    "H.R. College of Commerce & Economics",
    "Mithibai College",
    "Wilson College",
    "SIES College of Arts, Science & Commerce",
    "Thadomal Shahani Engineering College",
  ];

  function daysUntil(dateStr) {
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const target = new Date(dateStr);
    target.setHours(0, 0, 0, 0);
    return Math.round((target - today) / 86400000);
  }

  function formatDate(dateStr) {
    try {
      const d = new Date(dateStr);
      return d.toLocaleDateString("en-IN", {
        day: "2-digit",
        month: "short",
        year: "numeric",
      });
    } catch {
      return dateStr;
    }
  }

  function formatFee(fee) {
    const n = Number(fee);
    if (!n || n <= 0) return "Free entry";
    return "₹" + n.toLocaleString("en-IN");
  }

  /** Seed a handful of realistic sample events on first-ever visit only. */
  function seedIfEmpty() {
    let alreadySeeded = false;
    try {
      alreadySeeded = window.localStorage.getItem(SEED_FLAG) === "1";
    } catch {
      alreadySeeded = true; // if storage is unavailable, don't try to write
    }
    if (alreadySeeded) return;
    const existing = readAll();
    if (existing.length > 0) {
      try {
        window.localStorage.setItem(SEED_FLAG, "1");
      } catch {}
      return;
    }

    const today = new Date();
    const inDays = (n) => {
      const d = new Date(today);
      d.setDate(d.getDate() + n);
      return d.toISOString().slice(0, 10);
    };

    const demo = [
      {
        title: "CodeStorm 2026 — 24 Hour Hackathon",
        college: "K.J. Somaiya College of Engineering",
        city: "Mumbai",
        category: "Hackathon",
        description:
          "A 24-hour build sprint open to teams of 2–4 from any college. Tracks: FinTech, HealthTech, and Climate. Mentors on-site, meals and Wi-Fi provided, and prizes for the top three teams.",
        date: inDays(18),
        deadline: inDays(12),
        time: "09:00 AM",
        venue: "KJSCE Main Auditorium, Vidyavihar",
        mode: "Offline",
        entryFee: 500,
        teamSize: "2–4 members",
        registrationLink: "https://example.com/register/codestorm",
        organizerName: "Priya Nair",
        contactEmail: "codestorm@kjsce.example.edu",
        contactPhone: "+91 98200 00000",
      },
      {
        title: "Kaleidoscope — Annual Cultural Fest",
        college: "Jai Hind College",
        city: "Mumbai",
        category: "Cultural Fest",
        description:
          "Three days of music, dance, drama, and street-style competitions with cash prizes across 20+ events. Open to all college students with a valid ID.",
        date: inDays(30),
        deadline: inDays(25),
        time: "10:00 AM",
        venue: "Jai Hind College Grounds, Churchgate",
        mode: "Offline",
        entryFee: 150,
        teamSize: "Solo or team, varies by event",
        registrationLink: "https://example.com/register/kaleidoscope",
        organizerName: "Rohan Mehta",
        contactEmail: "fest@jaihind.example.edu",
        contactPhone: "+91 98100 00000",
      },
      {
        title: "TechSpeak: Careers in AI — Guest Talk",
        college: "VJTI Mumbai",
        city: "Mumbai",
        category: "Seminar / Guest Talk",
        description:
          "An evening talk and open Q&A with industry practitioners on breaking into applied AI roles, followed by a networking session. Free for all students, seats limited.",
        date: inDays(7),
        deadline: inDays(6),
        time: "05:30 PM",
        venue: "VJTI Seminar Hall, Matunga",
        mode: "Hybrid",
        entryFee: 0,
        teamSize: "Individual",
        registrationLink: "https://example.com/register/techspeak",
        organizerName: "Ananya Kulkarni",
        contactEmail: "events@vjti.example.edu",
        contactPhone: "+91 90040 00000",
      },
      {
        title: "InterCollege Basketball Championship",
        college: "St. Xavier's College, Mumbai",
        city: "Mumbai",
        category: "Sports Meet",
        description:
          "Five-a-side inter-college basketball championship with a knockout format. Teams must register in advance with a college ID list.",
        date: inDays(21),
        deadline: inDays(15),
        time: "08:00 AM",
        venue: "St. Xavier's Sports Complex",
        mode: "Offline",
        entryFee: 800,
        teamSize: "5 members + 2 substitutes",
        registrationLink: "https://example.com/register/basketball",
        organizerName: "Aditya Kamath",
        contactEmail: "sports@xaviers.example.edu",
        contactPhone: "+91 91670 00000",
      },
    ];

    const withIds = demo.map((d) => ({ id: uid(), createdAt: new Date().toISOString(), ...d }));
    writeAll(withIds);
    try {
      window.localStorage.setItem(SEED_FLAG, "1");
    } catch {}
  }

  return {
    getEvents,
    getEvent,
    addEvent,
    updateEvent,
    deleteEvent,
    verifyKey,
    getColleges,
    getCategories,
    daysUntil,
    formatDate,
    formatFee,
    seedIfEmpty,
    uid,
  };
})();
