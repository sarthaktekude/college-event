let EDIT_MODE = null; // { id, key } when editing an existing event

document.addEventListener("DOMContentLoaded", () => {
  renderChrome("post");
  Store.seedIfEmpty();

  const collegeList = document.getElementById("college-suggestions");
  if (collegeList) {
    Store.getColleges().forEach((c) => {
      const opt = document.createElement("option");
      opt.value = c;
      collegeList.appendChild(opt);
    });
  }

  const form = document.getElementById("post-event-form");
  form?.addEventListener("submit", handleSubmit);

  // Sensible default date bounds: event date cannot be in the past.
  const dateInput = document.getElementById("f-date");
  if (dateInput) dateInput.min = new Date().toISOString().slice(0, 10);

  setupEditModeIfRequested();
});

function setupEditModeIfRequested() {
  const editId = qs("edit");
  const key = qs("key") || "";
  if (!editId) return;

  const event = Store.getEvent(editId);
  if (!event || !Store.verifyKey(editId, key)) {
    showToast("That edit link is invalid or has expired.", "danger");
    return;
  }

  EDIT_MODE = { id: editId, key };

  document.getElementById("form-title").textContent = "Edit your event";
  document.getElementById("form-subtitle").textContent =
    "Update the details below — students who bookmarked this event will always see the latest version.";
  document.getElementById("submit-btn").textContent = "Save changes";
  document.getElementById("f-passcode").required = false;
  document.getElementById("passcode-field").querySelector(".hint").textContent =
    "Leave blank to keep your current passcode.";

  const set = (id, value) => {
    const el = document.getElementById(id);
    if (el && value !== undefined && value !== null) el.value = value;
  };
  set("f-title", event.title);
  set("f-college", event.college);
  set("f-city", event.city);
  set("f-category", event.category);
  set("f-date", event.date);
  set("f-deadline", event.deadline);
  set("f-time", event.time);
  set("f-venue", event.venue);
  set("f-mode", event.mode);
  set("f-fee", event.entryFee);
  set("f-teamsize", event.teamSize);
  set("f-description", event.description);
  set("f-link", event.registrationLink);
  set("f-organizer", event.organizerName);
  set("f-email", event.contactEmail);
  set("f-phone", event.contactPhone);
}

function setError(fieldId, message) {
  const field = document.getElementById(fieldId)?.closest(".field");
  if (!field) return;
  field.classList.toggle("has-error", Boolean(message));
  const errorEl = field.querySelector(".error");
  if (errorEl) errorEl.textContent = message || "";
}

function handleSubmit(evt) {
  evt.preventDefault();

  const get = (id) => document.getElementById(id)?.value.trim() || "";

  const data = {
    title: get("f-title"),
    college: get("f-college"),
    city: get("f-city"),
    category: get("f-category"),
    date: get("f-date"),
    deadline: get("f-deadline"),
    time: get("f-time"),
    venue: get("f-venue"),
    mode: get("f-mode"),
    entryFee: get("f-fee"),
    teamSize: get("f-teamsize"),
    description: get("f-description"),
    registrationLink: get("f-link"),
    organizerName: get("f-organizer"),
    contactEmail: get("f-email"),
    contactPhone: get("f-phone"),
    editKey: get("f-passcode"),
  };

  let valid = true;
  const required = [
    ["f-title", "Give your event a name."],
    ["f-college", "Tell students which college is hosting this."],
    ["f-category", "Choose a category."],
    ["f-date", "Pick a date for the event."],
    ["f-description", "Add a short description so students know what to expect."],
    ["f-organizer", "Add the organizer's name so students know who's running it."],
  ];
  if (!EDIT_MODE) {
    required.push(["f-passcode", "Set a passcode — you'll need it to edit or remove this event later."]);
  }

  required.forEach(([id, message]) => {
    if (!get(id)) {
      setError(id, message);
      valid = false;
    } else {
      setError(id, "");
    }
  });

  if (data.entryFee && (isNaN(Number(data.entryFee)) || Number(data.entryFee) < 0)) {
    setError("f-fee", "Entry fee must be a positive number, or left blank for free events.");
    valid = false;
  } else {
    setError("f-fee", "");
  }

  if (data.contactEmail && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(data.contactEmail)) {
    setError("f-email", "That doesn't look like a valid email address.");
    valid = false;
  } else {
    setError("f-email", "");
  }

  if (data.registrationLink && !/^https?:\/\//i.test(data.registrationLink)) {
    setError("f-link", "Links must start with http:// or https://");
    valid = false;
  } else {
    setError("f-link", "");
  }

  if (data.deadline && data.date && new Date(data.deadline) > new Date(data.date)) {
    setError("f-deadline", "The registration deadline should be on or before the event date.");
    valid = false;
  } else {
    setError("f-deadline", "");
  }

  if (data.editKey.length > 0 && data.editKey.length < 4) {
    setError("f-passcode", "Use at least 4 characters so it's not too easy to guess.");
    valid = false;
  }

  if (!valid) {
    showToast("Please fix the highlighted fields.", "danger");
    document.querySelector(".field.has-error")?.scrollIntoView({ behavior: "smooth", block: "center" });
    return;
  }

  data.entryFee = data.entryFee ? Number(data.entryFee) : 0;

  if (EDIT_MODE) {
    if (!data.editKey) delete data.editKey; // keep existing passcode if left blank
    const ok = Store.updateEvent(EDIT_MODE.id, data);
    if (!ok) {
      showToast("Something went wrong saving your changes. Please try again.", "danger");
      return;
    }
    showToast("Event updated.", "success");
    window.location.href = `event-detail.html?id=${encodeURIComponent(EDIT_MODE.id)}`;
    return;
  }

  const created = Store.addEvent(data);
  if (!created) {
    showToast("Something went wrong saving your event. Please try again.", "danger");
    return;
  }

  window.location.href = `event-posted.html?id=${encodeURIComponent(created.id)}`;
}
